// Serviço web para o Render (Node 18+, sem dependências). Recebe o payload do totem/plataforma e dispara pelo Resend.
// Deploy: crie um Web Service no Render apontando para este repositório com rootDir "server" (ou use o render.yaml
// na raiz). Variáveis: RESEND_API_KEY (obrigatória), RESEND_FROM, RESEND_REPLY_TO, ALLOW_ORIGIN.
// Depois cole a URL pública (https://vow-abras-email.onrender.com/send) em Plataforma → Configurações → Endpoint de envio.
import http from 'node:http';

const PORT = process.env.PORT || 10000;
const ALLOW_ORIGIN = process.env.ALLOW_ORIGIN || '*';
const cors = res => { res.setHeader('Access-Control-Allow-Origin', ALLOW_ORIGIN); res.setHeader('Access-Control-Allow-Methods', 'POST, GET, OPTIONS'); res.setHeader('Access-Control-Allow-Headers', 'Content-Type'); };
const json = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
const lerCorpo = req => new Promise((ok, err) => { let b = ''; req.on('data', c => { b += c; if (b.length > 2e6) req.destroy(); }); req.on('end', () => ok(b)); req.on('error', err); });

http.createServer(async (req, res) => {
  cors(res);
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  if (req.method === 'GET') return json(res, 200, { ok: true, servico: 'vow-abras-email', resend: !!process.env.RESEND_API_KEY });
  if (req.method !== 'POST' || !/^\/(send)?\/?$/.test(req.url.split('?')[0])) return json(res, 404, { error: 'Use POST /send' });
  const key = process.env.RESEND_API_KEY;
  if (!key) return json(res, 500, { error: 'RESEND_API_KEY não configurada no Render' });
  let body; try { body = JSON.parse(await lerCorpo(req) || '{}'); } catch { return json(res, 400, { error: 'JSON inválido' }); }
  const { to, from, reply_to, subject, html, text, tags, leadId } = body;
  if (!to || !subject || !html) return json(res, 400, { error: 'Campos obrigatórios: to, subject, html' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(to)) return json(res, 400, { error: 'E-mail inválido' });
  try {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST', headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: from || process.env.RESEND_FROM || 'VOW <diagnostico@vow.com.br>', to: [to], reply_to: reply_to || process.env.RESEND_REPLY_TO || undefined, subject, html, text, tags: [...(tags || []), ...(leadId ? [{ name: 'lead', value: String(leadId).replace(/[^A-Za-z0-9_-]/g, '') }] : [])] }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) return json(res, r.status, { error: j.message || j.name || 'Resend recusou o envio', detail: j });
    return json(res, 200, { ok: true, id: j.id });
  } catch (e) { return json(res, 502, { error: 'Falha ao falar com o Resend: ' + e.message }); }
}).listen(PORT, () => console.log('vow-abras-email na porta ' + PORT));
