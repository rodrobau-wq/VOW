# Handoff para o Claude Design — Plataforma VOW

**De:** sessão de trabalho de 01–02/09/2026 (Cowork) · **Para:** uma sessão do Claude Design
**Repositório:** `github.com/rodrobau-wq/VOW` · **Produção:** `vow-abras.onrender.com`

Este pacote existe porque memória não atravessa sessões. O que está aqui é o que uma sessão nova precisa saber para **não refazer decisão já tomada e não repetir erro já corrigido**.

---

## 1. O projeto em uma página

O Grupo VOW é uma consultoria tributária que atende redes de supermercado. A reforma — IBS e CBS, LC 214/2025 — transfere ao varejista responsabilidades que eram do governo. A VOW resolve isso hoje à mão; o projeto é virar plataforma.

**Alvo:** Smart Market ABRAS, 12 e 13 de abril de 2027. Antes disso, piloto pago.

**Três produtos**, com uma dependência que organiza tudo:

| | Produto | Responde | Papel comercial |
|---|---|---|---|
| Sistema 1 | Fornecedores | Este CNPJ está regular, e quanto do imposto volta como crédito? | Recorrência |
| Sistema 2 | Contratos | Meus contratos sustentam o crédito que estou tomando? | Retenção |
| Sistema 3 | Itens | Qual a alíquota certa de cada produto? | Aquisição |

O Sistema 3 define a alíquota efetiva de cada item, e é ela que diz quanto crédito está em risco em cada fornecedor e quanto vale cada contrato. **Alíquota cheia sobre tudo produz número falso** — esse é o erro que invalida qualquer tela de valor.

**Três camadas, não um app só.** Pública (landing, totem, diagnósticos) sem login, escura e cinematográfica. Comercial (leads, disparos) para o time VOW. SaaS (os três sistemas) para o cliente pagante, claro e sobre papel, porque é ferramenta de oito horas por dia. **A camada SaaS quase não existe** — é onde o desenho é mais necessário.

## 2. Decisões tomadas — não relitigar

**Sem valores em reais em material comercial.** Decisão explícita do cliente. Todo número na tela sai de entrada do usuário ou de cálculo sobre ela. Nada de "empresas como a sua economizam X". A promessa é "medimos na sua base".

**Nunca vender velocidade.** Nada de "em segundos" ou "o que levava quinze dias". Desvaloriza a consultoria, que é o negócio principal. O argumento é segurança, compliance e crédito preservado.

**Bloqueio de fornecedor é sugestão mais aprovação**, nunca automático sem alçada.

**Regra de ouro:** nenhum título pago sem contrato vinculado e fornecedor fora do vermelho. Gate no ERP, ligado depois de ~30 dias de alerta — antes disso o financeiro para de operar no primeiro dia.

**Ordem de implantação:** fornecedores primeiro, porque é a base; depois cobertura contratual; depois regularizar; depois operar.

**Assinatura eletrônica é integração com assinador de mercado sob a marca VOW**, não desenvolvimento próprio. Validade jurídica e cadeia ICP-Brasil não são um sprint.

**Financeiros** — empréstimo, FIDC, adquirência, seguros — são inventariados mas ficam **fora do motor de cláusulas**: têm regime específico na LC 214 e vão para a consultoria.

## 3. Decisões descartadas — e por quê

**Protótipos navegáveis anteriores dos três produtos:** apagados. Começavam pela "carteira" como se o cliente já tivesse tudo organizado. A jornada estava confusa. Reaproveitar ideias, nunca a estrutura.

**Simulação por porte com valores inventados no totem:** descartada, substituída por captura de lead e diagnóstico.

**Preços de referência em R$/CNPJ:** eram invenção de protótipo. Não usar.

**Jornada por "fases de implantação" como eixo das telas:** o cliente prefere pensar pelos **seis momentos da operação** onde a decisão acontece — cadastrar o item, cotar, emitir o pedido, receber a nota, pagar, fechar acordo. Esse é o eixo.

**Simulador inline na landing:** removido. Havia dois cálculos do mesmo número no mesmo produto e eles iam divergir. O totem é a fonte única, e os botões da landing abrem `/totem`.

## 4. O sistema de design

Já existe e está extraído em `tokens.css` — use, não reinvente.

```
--bg:#0E1B14   --bg-deep:#07110C   --surface:#15261C   --raised:#1C3225
--ink:#F3EEE2  --dim:#C9D2C8       --muted:#9FB0A2     --faint:#6F8074
--gold:#E0C48C --gold-deep:#B8934A --risk:#E8906C      --ok:#7BD389
--paper:#EFE9DB  --paper-card:#FBF8F1   --paper-ink:#0E1B14
--line:rgba(243,238,226,.10)   --line-2:rgba(243,238,226,.18)
```

**IBM Plex Sans** na interface, **Instrument Serif** nos números grandes e nos títulos. Nunca serif em botão ou dado tabular. Raios de 14 a 32px. Números sempre em `tabular-nums`, padrão brasileiro: `R$ 1.234.567,89`. Sem emoji, sem degradê, sem sombra colorida.

Há um manual de marca anterior com paleta grafite e dourado (`#16181A` / `#B08A3E`, Manrope + Source Serif 4). **Está superado** pela paleta verde-escura acima, que é a que está em produção. Se alguém abrir o manual antigo, é isso.

**Regra de contraste entre camadas:** público escuro, plataforma interna clara. A tela de leads já acertou isso.

## 5. Três regras de conteúdo que a interface precisa respeitar

**Dois eixos, não um semáforo.** Risco ("o débito vai ser extinto?") e classe de crédito ("quanto volta pra mim?") são perguntas independentes. Um MEI perfeitamente regular é verde em risco e péssimo em crédito. **Um fornecedor pode ser um problema sem ser irregular** — é a ideia mais original do produto e ela precisa estar visível, não escondida dentro do verde.

**Cor não decide sozinha.** Vermelho de tributado contra verde de não tributado é um par ruim para daltonismo — ΔE 7,6 em deuteranopia, medido. Todo item colorido carrega o rótulo escrito, ou usa vermelho contra um neutro.

**Dizer o que ainda não se sabe.** Várias premissas estão pendentes de validação do time fiscal da VOW. A interface ganha credibilidade marcando isso, não escondendo.

## 6. O que existe hoje, tela por tela

Em `telas/`:

| Arquivo | Rota | Estado |
|---|---|---|
| `landing.html` | `/` | Em produção. Precisa de refino, não de redesenho |
| `index.html` | `/totem-v1` | Totem codado, grava lead no servidor e marca origem |
| `leads.html` | `/leads` | Plataforma de leads, protegida |
| `app-entrar.html` | `/app/entrar` | Esboço da Fase 1 |
| `app-redes.html` | `/app/redes` | Esboço |
| `app-inicio.html` | `/app/inicio` | Esboço |
| `app-painel.html` | `/app` | Esboço — a tela mais importante e a menos resolvida |

O protótipo AS IS / TO BE exportado do Claude Design está servido em `/totem` e vive em `public/abras/`. Ele tem runtime e **motor próprios**, diferentes do motor da casa — duas aritméticas no mesmo produto, pendente de resolver na portabilidade.

## 7. O que falta desenhar, em ordem de dificuldade

1. **Painel** (`/app`) — quatro números e uma fila de exceções. Responde "o que preciso olhar hoje", não "quanto de dado vocês têm". É a tela que justifica a assinatura e a mais difícil de acertar.
2. **Ficha do fornecedor** (`/app/fornecedores/:cnpj`) — sete blocos de análise e um score decomposto, num espaço que caiba na cabeça de um comprador com pressa.
3. **Mapa da carteira** (`/app/fornecedores/mapa`) — matriz risco × classe de crédito, tamanho pela exposição de imposto. É o "uau" da demonstração.
4. **Cobertura contratual** (`/app/contratos`) — uma lista longa de CNPJs pagos sem contrato, que precisa dar vontade de agir e não de fechar a aba.
5. **Portal do fornecedor** (`/f/:token`) — a única tela externa do SaaS. Tem que funcionar no celular de um vendedor de câmara fria, com sinal ruim. Ele declara o próprio regime tributário, porque essa informação **não é consultável por terceiros** — é a razão de a tela existir.

O mapa completo das 22 telas está em `contexto/ABRAS - Plataforma - Arquitetura e Telas.md`.

## 8. Onde está a regra de negócio

Em `contexto/`. Leia o que a tarefa pedir:

| Arquivo | Assunto |
|---|---|
| `ABRAS - Sistema 1 - Fornecedores.md` | O produto, os seis ganhos, o Raio-X em sete blocos |
| `ABRAS - Sistema 2 - Contratos.md` | Oito tipos de contrato, o gate de pagamento |
| `ABRAS - Sistema 3 - Itens.md` | Saneamento, base mestre, recuperação retroativa |
| `ABRAS - Contrato de Revenda.md` | Oito modalidades de aquisição de mercadoria |
| `ABRAS - Verbas Comerciais.md` | Oito contratos e sete verbas do acordo com a indústria |
| `ABRAS - Contrato de Indiretos.md` | Sete famílias de serviço |
| `ABRAS - Plataforma - Arquitetura e Telas.md` | As 22 telas e o modelo de dados |

Os textos desses arquivos são **copy aprovada**. Reaproveite em vez de reescrever.

## 9. O pedido

Desenhar as cinco telas da seção 7, na ordem, usando `tokens.css` e respeitando as regras da seção 5. Entregar como `.dc.html`, no mesmo formato dos pacotes anteriores.

**Duas coisas que ajudam quem recebe depois:** manter os tokens no arquivo único em vez de repetir cores inline em cada tela — a duplicação já começou a divergir; e, se o pacote for servido direto no Render, lembrar que cada `.dc.html` precisa de `<base href="/abras/">` logo depois do `<head>`, senão o `./support.js` resolve para a raiz e a tela abre em branco sem erro no console.
